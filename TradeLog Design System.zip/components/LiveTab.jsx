// LiveTab.jsx — MT5 live positions, execution pipeline, pending orders
function LiveTab() {
  const [positions] = React.useState([
    { ticket:1234567, symbol:'BTCUSDT', dir:'Short', entry:67800, current:68100, sl:68400, tp:65500, lots:0.03, pnl:-90, openTime:'2026-04-24 09:15', paper:true },
    { ticket:1234568, symbol:'GBPUSD',  dir:'Long',  entry:1.2695, current:1.2712, sl:1.2660, tp:1.2780, lots:0.5, pnl:85, openTime:'2026-04-24 08:02', paper:true },
  ]);
  const [execQueue] = React.useState([]);
  const [pending] = React.useState([
    { id:'exec_001', symbol:'EURUSD', dir:'BUY', entry:1.0720, sl:1.0685, tp:1.0810, lotSize:0.3, status:'limit_placed', ticket:9988001, placedAt:'2026-04-24 07:45' },
  ]);
  const [sysStatus] = React.useState({
    backend: 'offline', ea: 'disconnected', paper: true, emergencyStop: false
  });
  const [execLog] = React.useState([
    { ts:'09:15:32', event:'Limit FILLED — BTCUSDT Short @ 67800', type:'success' },
    { ts:'07:45:11', event:'BUY LIMIT placed — EURUSD @ 1.0720 | expires 24h', type:'limit' },
    { ts:'07:44:58', event:'Trade approved — EURUSD Long | lot=0.3 | paper=true', type:'approved' },
    { ts:'06:30:00', event:'Heartbeat OK — equity $10,085', type:'success' },
  ]);

  const pnlColor = (v) => v > 0 ? 'var(--green)' : v < 0 ? 'var(--red)' : 'var(--t3)';

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16, paddingBottom:40 }}>
      {/* System status bar */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:10 }}>
        {[
          { label:'Backend', val: sysStatus.backend==='online'?'Online':'Offline', color: sysStatus.backend==='online'?'var(--green)':'var(--red)' },
          { label:'MT5 EA', val: sysStatus.ea==='connected'?'Connected':'Disconnected', color: sysStatus.ea==='connected'?'var(--green)':'var(--t3)' },
          { label:'Mode', val: sysStatus.paper?'Paper Trading':'Live', color: sysStatus.paper?'var(--amber)':'var(--green)' },
          { label:'Emergency', val: sysStatus.emergencyStop?'ACTIVE':'Clear', color: sysStatus.emergencyStop?'var(--red)':'var(--green)' },
        ].map(s => (
          <div key={s.label} style={{ background:'var(--s2)', border:'1px solid var(--border)', borderRadius:10, padding:'12px 16px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontSize:12, color:'var(--t3)' }}>{s.label}</span>
            <span style={{ fontSize:12, fontWeight:600, color:s.color, display:'flex', alignItems:'center', gap:6 }}>
              <span style={{ width:6, height:6, borderRadius:'50%', background:s.color, display:'inline-block' }}/>
              {s.val}
            </span>
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        {/* Live positions */}
        <div style={{ gridColumn:'1/-1' }}>
          <SectionHead title="Live MT5 Positions" count={positions.length} accent="var(--green)"/>
          {positions.length === 0 ? (
            <Empty msg="No open positions. Connect MT5 EA to see live trades."/>
          ) : positions.map(p => (
            <PositionCard key={p.ticket} p={p} pnlColor={pnlColor}/>
          ))}
        </div>

        {/* Pending limit orders */}
        <div>
          <SectionHead title="Pending Limit Orders" count={pending.length} accent="var(--amber)"/>
          {pending.length === 0 ? <Empty msg="No pending limit orders."/> : pending.map(o => (
            <div key={o.id} style={{ background:'var(--s2)', border:'1px solid var(--border)', borderLeft:'3px solid var(--amber)', borderRadius:10, padding:'14px 16px', marginBottom:10 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                <div>
                  <span style={{ fontFamily:'var(--mono)', fontWeight:700, fontSize:15, color:'var(--t1)' }}>{o.symbol}</span>
                  <span style={{ marginLeft:8, fontSize:11, padding:'2px 8px', borderRadius:4, fontWeight:600,
                    background: o.dir==='BUY'?'rgba(34,197,94,0.1)':'rgba(239,68,68,0.1)',
                    color: o.dir==='BUY'?'var(--green)':'var(--red)' }}>{o.dir}</span>
                </div>
                <span style={{ fontSize:11, color:'var(--amber)', background:'rgba(245,158,11,0.1)', padding:'2px 8px', borderRadius:4 }}>LIMIT PENDING</span>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
                {[['Entry',o.entry],['SL',o.sl],['TP',o.tp],['Lot',o.lotSize]].map(([k,v])=>(
                  <div key={k} style={{ background:'var(--s3)', borderRadius:7, padding:'7px 10px' }}>
                    <div style={{ fontSize:10, color:'var(--t3)' }}>{k}</div>
                    <div style={{ fontFamily:'var(--mono)', fontSize:13, fontWeight:600, color:'var(--t1)' }}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{ fontSize:11, color:'var(--t3)', marginTop:10 }}>Placed {o.placedAt} · Ticket #{o.ticket}</div>
            </div>
          ))}
        </div>

        {/* Execution queue */}
        <div>
          <SectionHead title="Execution Queue" count={execQueue.length} accent="var(--blue)"/>
          {execQueue.length === 0 ? (
            <Empty msg="No trades waiting for execution."/>
          ) : null}
        </div>
      </div>

      {/* Execution log */}
      <div>
        <SectionHead title="Execution Log" accent="var(--t3)"/>
        <div style={{ background:'var(--s2)', border:'1px solid var(--border)', borderRadius:10, overflow:'hidden' }}>
          {execLog.map((l, i) => (
            <div key={i} style={{ display:'flex', gap:14, alignItems:'center', padding:'10px 16px',
              borderBottom: i < execLog.length-1 ? '1px solid var(--border)' : 'none' }}>
              <span style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--t3)', flexShrink:0 }}>{l.ts}</span>
              <span style={{ width:6, height:6, borderRadius:'50%', flexShrink:0,
                background: l.type==='success'?'var(--green)':l.type==='limit'?'var(--amber)':l.type==='approved'?'var(--blue)':'var(--t3)' }}/>
              <span style={{ fontSize:12, color:'var(--t2)' }}>{l.event}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      <div style={{ display:'flex', gap:10 }}>
        <button style={{ flex:1, padding:'11px', borderRadius:8, border:'1px solid var(--border)', background:'var(--s2)', color:'var(--t2)', fontSize:13, cursor:'pointer', fontWeight:500 }}>↻ Refresh</button>
        <button style={{ flex:1, padding:'11px', borderRadius:8, border:'1px solid rgba(245,158,11,0.3)', background:'rgba(245,158,11,0.08)', color:'var(--amber)', fontSize:13, cursor:'pointer', fontWeight:600 }}>🧪 Test Pipeline</button>
        <button style={{ flex:1, padding:'11px', borderRadius:8, border:'1px solid rgba(239,68,68,0.3)', background:'rgba(239,68,68,0.08)', color:'var(--red)', fontSize:13, cursor:'pointer', fontWeight:600 }}>🛑 Emergency Stop</button>
      </div>
    </div>
  );
}

function PositionCard({ p, pnlColor }) {
  const riskDist = Math.abs(p.entry - p.sl);
  const profDist = Math.abs(p.current - p.entry);
  const pct = riskDist > 0 ? Math.min(100, (profDist / riskDist) * 100 * (p.pnl > 0 ? 1 : -1)) : 0;

  return (
    <div style={{ background:'var(--s2)', border:'1px solid var(--border)',
      borderLeft:`3px solid ${p.pnl > 0 ? 'var(--green)' : p.pnl < 0 ? 'var(--red)' : 'var(--t3)'}`,
      borderRadius:10, padding:'16px', marginBottom:10 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ fontFamily:'var(--mono)', fontWeight:700, fontSize:16, color:'var(--t1)' }}>{p.symbol}</span>
          <span style={{ fontSize:12, padding:'3px 10px', borderRadius:5, fontWeight:600,
            background: p.dir==='Long'?'rgba(34,197,94,0.12)':'rgba(239,68,68,0.12)',
            color: p.dir==='Long'?'var(--green)':'var(--red)' }}>▲ {p.dir}</span>
          {p.paper && <span style={{ fontSize:10, padding:'2px 7px', borderRadius:4, background:'rgba(245,158,11,0.1)', color:'var(--amber)', fontWeight:600 }}>PAPER</span>}
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontFamily:'var(--mono)', fontWeight:700, fontSize:18, color:pnlColor(p.pnl) }}>
            {p.pnl > 0 ? '+' : ''}${p.pnl}
          </div>
          <div style={{ fontSize:10, color:'var(--t3)' }}>Unrealized P&L</div>
        </div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:8, marginBottom:12 }}>
        {[['Entry', p.entry],['Current', p.current],['SL', p.sl],['TP', p.tp],['Lots', p.lots]].map(([k,v])=>(
          <div key={k} style={{ background:'var(--s3)', borderRadius:7, padding:'8px 10px' }}>
            <div style={{ fontSize:10, color:'var(--t3)', marginBottom:3 }}>{k}</div>
            <div style={{ fontFamily:'var(--mono)', fontSize:13, fontWeight:600,
              color: k==='SL'?'var(--red)':k==='TP'?'var(--green)':'var(--t1)' }}>{v}</div>
          </div>
        ))}
      </div>
      {/* Progress bar toward TP */}
      <div style={{ height:4, background:'var(--s3)', borderRadius:2, overflow:'hidden' }}>
        <div style={{ height:'100%', width:`${Math.abs(pct)}%`, borderRadius:2, transition:'width 0.5s',
          background: p.pnl > 0 ? 'var(--green)' : 'var(--red)' }}/>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', fontSize:10, color:'var(--t3)', marginTop:4 }}>
        <span>SL {p.sl}</span>
        <span style={{ color:'var(--t2)' }}>Entry {p.entry}</span>
        <span>TP {p.tp}</span>
      </div>
      <div style={{ fontSize:11, color:'var(--t3)', marginTop:10 }}>Ticket #{p.ticket} · Opened {p.openTime}</div>
    </div>
  );
}

function SectionHead({ title, count, accent }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
      {accent && <span style={{ width:3, height:16, background:accent, borderRadius:2 }}/>}
      <span style={{ fontWeight:600, fontSize:14, color:'var(--t1)' }}>{title}</span>
      {count !== undefined && <span style={{ fontSize:11, background:'var(--s3)', color:'var(--t3)', borderRadius:10, padding:'1px 8px' }}>{count}</span>}
    </div>
  );
}

function Empty({ msg }) {
  return (
    <div style={{ background:'var(--s2)', border:'1px solid var(--border)', borderRadius:10, padding:'28px 20px', textAlign:'center', color:'var(--t3)', fontSize:13, marginBottom:10 }}>
      {msg}
    </div>
  );
}

Object.assign(window, { LiveTab, SectionHead, Empty });
