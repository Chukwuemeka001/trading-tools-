// Sample trades for prototype
const SAMPLE_TRADES = [
  { id:1, pair:'GBP/USD', dir:'Long',  setup:'Secondary POI + SC entry',   entry:1.2650, sl:1.2610, tp:1.2730, size:0.5,  risk:100, rr:2.0,  pnl:200,  outcome:'Win',  status:'Closed', market:'Forex',   session:'London',   conf:8, date:'2026-04-14', htfBias:'Bullish' },
  { id:2, pair:'EUR/USD', dir:'Short', setup:'HTF liquidity sweep entry',   entry:1.0890, sl:1.0930, tp:1.0810, size:0.3,  risk:75,  rr:2.0,  pnl:-75,  outcome:'Loss', status:'Closed', market:'Forex',   session:'NY',       conf:6, date:'2026-04-15', htfBias:'Bearish' },
  { id:3, pair:'BTC/USDT',dir:'Long',  setup:'Primary POI + SC entry',      entry:64200,  sl:63500,  tp:66000,  size:0.04, risk:120, rr:2.57, pnl:308,  outcome:'Win',  status:'Closed', market:'BTC/USDT',session:'Asian',    conf:9, date:'2026-04-16', htfBias:'Bullish' },
  { id:4, pair:'GBP/JPY', dir:'Long',  setup:'Trusted BOS entry',           entry:197.50, sl:197.10, tp:198.30, size:0.2,  risk:80,  rr:2.0,  pnl:160,  outcome:'Win',  status:'Closed', market:'Forex',   session:'London',   conf:7, date:'2026-04-17', htfBias:'Bullish' },
  { id:5, pair:'USD/CAD', dir:'Short', setup:'mbms confirmation entry',     entry:1.3820, sl:1.3860, tp:1.3740, size:0.25, risk:60,  rr:2.0,  pnl:-60,  outcome:'Loss', status:'Closed', market:'Forex',   session:'NY',       conf:5, date:'2026-04-18', htfBias:'Bearish' },
  { id:6, pair:'GBP/USD', dir:'Long',  setup:'Secondary POI + SC entry',   entry:1.2720, sl:1.2685, tp:1.2810, size:0.5,  risk:100, rr:2.57, pnl:257,  outcome:'Win',  status:'Closed', market:'Forex',   session:'London',   conf:8, date:'2026-04-21', htfBias:'Bullish' },
  { id:7, pair:'EUR/GBP', dir:'Short', setup:'SC reaction only',            entry:0.8560, sl:0.8585, tp:0.8510, size:0.4,  risk:80,  rr:2.0,  pnl:160,  outcome:'Win',  status:'Closed', market:'Forex',   session:'London',   conf:7, date:'2026-04-22', htfBias:'Bearish' },
  { id:8, pair:'BTC/USDT',dir:'Short', setup:'HTF liquidity sweep entry',   entry:67800,  sl:68400,  tp:65500,  size:0.03, risk:100, rr:3.83, pnl:0,    outcome:null,   status:'Open',   market:'BTC/USDT',session:'NY',       conf:8, date:'2026-04-23', htfBias:'Bearish' },
  { id:9, pair:'GBP/USD', dir:'Long',  setup:'Primary POI + SC entry',      entry:1.2695, sl:1.2660, tp:1.2780, size:0.5,  risk:100, rr:2.43, pnl:0,    outcome:null,   status:'Open',   market:'Forex',   session:'London',   conf:9, date:'2026-04-24', htfBias:'Bullish' },
];

// Equity curve data (cumulative P&L by day)
const EQUITY_DATA = [
  { date:'Apr 1',  pnl:0 },
  { date:'Apr 3',  pnl:85 },
  { date:'Apr 7',  pnl:220 },
  { date:'Apr 8',  pnl:140 },
  { date:'Apr 10', pnl:340 },
  { date:'Apr 14', pnl:540 },
  { date:'Apr 15', pnl:465 },
  { date:'Apr 16', pnl:773 },
  { date:'Apr 17', pnl:933 },
  { date:'Apr 18', pnl:873 },
  { date:'Apr 21', pnl:1130 },
  { date:'Apr 22', pnl:1290 },
  { date:'Apr 23', pnl:1290 },
  { date:'Apr 24', pnl:1290 },
];

const SETUP_STATS = [
  { name:'Secondary POI + SC', trades:12, wins:9,  avgRR:2.1 },
  { name:'Primary POI + SC',   trades:6,  wins:5,  avgRR:2.4 },
  { name:'HTF Liq. Sweep',     trades:8,  wins:5,  avgRR:2.8 },
  { name:'Trusted BOS',        trades:5,  wins:3,  avgRR:1.9 },
  { name:'mbms confirmation',  trades:4,  wins:2,  avgRR:2.0 },
  { name:'SC reaction only',   trades:3,  wins:2,  avgRR:1.8 },
];

const SESSION_STATS = [
  { name:'London', wins:18, losses:5,  total:23 },
  { name:'NY',     wins:10, losses:8,  total:18 },
  { name:'Asian',  wins:4,  losses:3,  total:7  },
];

const IMPROVEMENTS = [
  { cat:'Navigation & UX', items:[
    'Mobile bottom navigation bar (was: cramped top tabs)',
    'Collapsible sidebar on desktop with hover tooltips',
    'Smoother tab transitions with fade animations',
    'Active state indicators and badge counts on nav icons',
  ]},
  { cat:'Dashboard', items:[
    'Real-time SVG equity curve with hover tooltips',
    'Win rate donut chart with session breakdown',
    'Setup performance bar chart with visual comparison',
    '"This week vs last week" delta comparison cards',
    'Streak tracker with colored pill indicators',
    'Drawdown meter as visual fill gauge',
    'Calendar heatmap for daily trade frequency',
    'Open trades P&L exposure at a glance',
  ]},
  { cat:'Log Trade Form', items:[
    'Multi-step wizard (4 clear steps, not one massive form)',
    'Inline position size calculator — no need to switch pages',
    'Auto-calculated R:R as you type Entry/SL/TP',
    'Progress bar showing form completion percentage',
    'Auto-save draft every 30 seconds with indicator',
    'Sticky review bar showing key levels throughout form',
    'Risk gauge showing how close to daily/weekly limit',
  ]},
  { cat:'Journal', items:[
    'Improved trade cards — key metrics visible at a glance',
    'Quick-edit inline for outcome and P&L',
    'Search by pair, setup, date, or outcome',
    'Sort by R:R, P&L, date, or confidence',
    'Expandable detail row without needing a full modal',
    'Win/loss streak shown on card header',
    'Bulk export / bulk delete',
  ]},
  { cat:'Calculator', items:[
    'Real-time calculation as you type — no submit needed',
    'Multiple TP levels (TP1, TP2, TP3) with split sizing',
    'Margin requirement estimation',
    'Position size shown as % of account',
    'Visual R:R scale bar',
    'History of last 5 calculations',
    'Copy individual values (not just full export)',
  ]},
  { cat:'Alerts & Live', items:[
    'Badge counter on nav when alerts fire',
    'Price distance gauge on each alert card',
    'Sound notification toggle',
    'Telegram webhook option',
    'MT5 connection status always visible in header',
  ]},
  { cat:'Performance & Infrastructure', items:[
    'PWA manifest — installable as a home screen app',
    'Loading skeletons instead of blank empty states',
    'Toast notifications for every action',
    'Better error states when backend is offline',
    'Offline-ready: read journal without internet',
  ]},
];

Object.assign(window, { SAMPLE_TRADES, EQUITY_DATA, SETUP_STATS, SESSION_STATS, IMPROVEMENTS });
