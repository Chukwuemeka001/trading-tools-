// Settings.jsx — Left sidebar nav + 8 sections
function Settings() {
  const [section, setSection] = React.useState('profile');
  const [saved, setSaved] = React.useState(false);
  const [vals, setVals] = React.useState({
    traderName: '', currency: 'USD', startingCapital: 10000,
    defaultRisk: 1, riskCap: 2, beRR: 1.5,
    timezone: 'UTC', defaultTF: 'H1', defaultMarket: 'Forex',
    dailyDD: 5, weeklyDD: 10, monthlyDD: 20,
    execKey: '', autoExec: 'manual', minScore: 7,
    requireChecklist: true, sessionMonitor: true,
    equityCurve: true, publicProfile: false,
    githubToken: '', gistId: '',
    backendURL: 'https://poiwatcher-backend.onrender.com',
    paperMode: true,
  });
  const set = (k, v) => setVals(s => ({ ...s, [k]: v }));
  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 1800); };

  const SECTIONS = [
    { id:'profile',    icon:'👤', label:'Profile' },
    { id:'risk',       icon:'⚠️',  label:'Risk Limits' },
    { id:'display',    icon:'🖥️',  label:'Display' },
    { id:'mt5',        icon:'📡',  label:'MT5 / Backend' },
    { id:'execution',  icon:'⚡',  label:'Execution' },
    { id:'sync',       icon:'☁️',  label:'Cloud Sync' },
    { id:'export',     icon:'📤',  label:'Export' },
    { id:'danger',     icon:'🗑️',  label:'Danger Zone' },
  ];

  const inp = (extra={}) => ({
    background:'var(--s3)', border:'1px solid var(--border)', borderRadius:8,
    padding:'10px 13px', color:'var(--t1)', fontSize:14, outline:'none',
    boxSizing:'border-box', fontFamily:'inherit', width:'100%', ...extra
  });
  const lbl = { fontSize:12, color:'var(--t3)', marginBottom:6, display:'block', letterSpacing:'0.04em' };
  const Field = ({ label, children }) => (
    <div style={{ marginBottom:18 }}><label style={lbl}>{label}</label>{children}</div>
  );
  const Row = ({ children }) => <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>{children}</div>;

  const Toggle2 = ({ val, onChange, label }) => (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 0', borderBottom:'1px solid var(--border)' }}>
      <span style={{ fontSize:14, color:'var(--t2)' }}>{label}</span>
      <div onClick={() => onChange(!val)} style={{
        width:40, height:22, borderRadius:11, background: val?'var(--blue)':'var(--s3)',
        border:`1px solid ${val?'var(--blue)':'var(--border)'}`, cursor:'pointer', position:'relative', transition:'all 0.2s'
      }}>
        <div style={{ position:'absolute', top:3, left: val?20:3, width:14, height:14, borderRadius:'50%', background:'#fff', transition:'left 0.2s' }}/>
      </div>
    </div>
  );

  const content = {
    profile: (
      <div>
        <H2>Profile</H2>
        <Row><Field label="Trader Name"><input style={inp()} value={vals.traderName} onChange={e=>set('traderName',e.target.value)} placeholder="Your name"/></Field>
          <Field label="Account Currency">
            <select style={inp({cursor:'pointer'})} value={vals.currency} onChange={e=>set('currency',e.target.value)}>
              {['USD','GBP','EUR','CAD'].map(c=><option key={c}>{c}</option>)}
            </select>
          </Field>
        </Row>
        <Field label="Starting Capital">
          <input style={inp({fontFamily:'var(--mono)'})} type="number" value={vals.startingCapital} onChange={e=>set('startingCapital',+e.target.value)}/>
        </Field>
        <Row>
          <Field label="Default Timeframe">
            <select style={inp({cursor:'pointer'})} value={vals.defaultTF} onChange={e=>set('defaultTF',e.target.value)}>
              {['M1','M5','M15','H1','H4','D1','W1'].map(t=><option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Default Market">
            <select style={inp({cursor:'pointer'})} value={vals.defaultMarket} onChange={e=>set('defaultMarket',e.target.value)}>
              {['Forex','BTC/USDT','Indices','Commodities'].map(m=><option key={m}>{m}</option>)}
            </select>
          </Field>
        </Row>
        <Field label="Timezone">
          <select style={inp({cursor:'pointer'})} value={vals.timezone} onChange={e=>set('timezone',e.target.value)}>
            {['UTC','Local (browser)','US Eastern','London'].map(t=><option key={t}>{t}</option>)}
          </select>
        </Field>
      </div>
    ),
    risk: (
      <div>
        <H2>Risk Limits</H2>
        <Row>
          <Field label="Default Risk % per Trade">
            <input style={inp({fontFamily:'var(--mono)'})} type="number" step="0.1" value={vals.defaultRisk} onChange={e=>set('defaultRisk',+e.target.value)}/>
          </Field>
          <Field label="Risk Cap % (hard max)">
            <input style={inp({fontFamily:'var(--mono)'})} type="number" step="0.1" value={vals.riskCap} onChange={e=>set('riskCap',+e.target.value)}/>
          </Field>
        </Row>
        <Field label={`Break Even Trigger (R:R) — currently ${vals.beRR}`}>
          <input type="range" min={1} max={3} step={0.5} value={vals.beRR} onChange={e=>set('beRR',+e.target.value)}
            style={{ width:'100%', accentColor:'var(--blue)', marginBottom:4 }}/>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'var(--t3)' }}>
            {[1,1.5,2,2.5,3].map(v=><span key={v}>{v}R</span>)}
          </div>
        </Field>
        <H3>Drawdown Limits</H3>
        {[['dailyDD','Daily Drawdown %'],['weeklyDD','Weekly Drawdown %'],['monthlyDD','Monthly Drawdown %']].map(([k,l])=>(
          <Field key={k} label={l}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <input style={{ ...inp(), flex:1 }} type="number" value={vals[k]} onChange={e=>set(k,+e.target.value)}/>
              <span style={{ fontFamily:'var(--mono)', color:'var(--amber)', fontWeight:700, width:40, textAlign:'right' }}>{vals[k]}%</span>
            </div>
          </Field>
        ))}
      </div>
    ),
    display: (
      <div>
        <H2>Display</H2>
        <Toggle2 val={vals.sessionMonitor} onChange={v=>set('sessionMonitor',v)} label="Show session clock bar"/>
        <Toggle2 val={vals.equityCurve} onChange={v=>set('equityCurve',v)} label="Show equity curve on dashboard"/>
        <Toggle2 val={vals.publicProfile} onChange={v=>set('publicProfile',v)} label="Public profile (share stats)"/>
      </div>
    ),
    mt5: (
      <div>
        <H2>MT5 / Backend</H2>
        <Field label="Backend URL">
          <input style={inp({fontFamily:'var(--mono)',fontSize:12})} value={vals.backendURL} onChange={e=>set('backendURL',e.target.value)}/>
        </Field>
        <Toggle2 val={vals.paperMode} onChange={v=>set('paperMode',v)} label="Paper trading mode (no live execution)"/>
        <div style={{ marginTop:20 }}>
          <div style={{ fontSize:12, color:'var(--t3)', marginBottom:10 }}>Connection Status</div>
          <div style={{ background:'var(--s3)', borderRadius:10, padding:14, display:'flex', flexDirection:'column', gap:10 }}>
            {[['Backend',false],['MT5 EA',false],['Price Feed',false]].map(([k,v])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between' }}>
                <span style={{ fontSize:13, color:'var(--t2)' }}>{k}</span>
                <span style={{ fontSize:12, color:v?'var(--green)':'var(--red)', display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ width:6, height:6, borderRadius:'50%', background:v?'var(--green)':'var(--red)' }}/>
                  {v?'Online':'Offline'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    ),
    execution: (
      <div>
        <H2>Execution Pipeline</H2>
        <Field label="Execution API Key">
          <input style={inp({fontFamily:'var(--mono)',fontSize:12})} type="password" value={vals.execKey} onChange={e=>set('execKey',e.target.value)} placeholder="Matches EXECUTION_API_KEY on backend"/>
        </Field>
        <Field label="Auto-Execution Mode">
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {[['manual','Manual approval only (recommended)'],['auto-score','Auto-approve if score ≥ threshold'],['auto-all','Auto-approve all (not recommended)']].map(([v,l])=>(
              <label key={v} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 12px', borderRadius:8,
                border:`1px solid ${vals.autoExec===v?'var(--blue)':'var(--border)'}`,
                background: vals.autoExec===v?'rgba(59,130,246,0.08)':'var(--s3)', cursor:'pointer' }}>
                <input type="radio" checked={vals.autoExec===v} onChange={()=>set('autoExec',v)} style={{ accentColor:'var(--blue)' }}/>
                <span style={{ fontSize:13, color: vals.autoExec===v?'var(--t1)':'var(--t2)' }}>{l}</span>
              </label>
            ))}
          </div>
        </Field>
        <Field label={`Min System Alignment Score — ${vals.minScore}/10`}>
          <input type="range" min={1} max={10} value={vals.minScore} onChange={e=>set('minScore',+e.target.value)}
            style={{ width:'100%', accentColor:'var(--blue)' }}/>
        </Field>
        <Toggle2 val={vals.requireChecklist} onChange={v=>set('requireChecklist',v)} label="Require pre-trade checklist before approval"/>
      </div>
    ),
    sync: (
      <div>
        <H2>Cloud Sync</H2>
        <p style={{ fontSize:13, color:'var(--t3)', marginBottom:20, lineHeight:1.6 }}>Sync your trades to a private GitHub Gist. Trades load automatically even without a token — only write operations need the token.</p>
        <Field label="GitHub Personal Access Token (gist scope)">
          <input style={inp({fontFamily:'var(--mono)',fontSize:12})} type="password" value={vals.githubToken} onChange={e=>set('githubToken',e.target.value)} placeholder="ghp_..."/>
        </Field>
        <Field label="Gist ID">
          <input style={inp({fontFamily:'var(--mono)',fontSize:12})} value={vals.gistId} onChange={e=>set('gistId',e.target.value)} placeholder="Hardcoded after first sync"/>
        </Field>
        <div style={{ display:'flex', gap:10 }}>
          <button style={{ flex:1, padding:'10px', borderRadius:8, border:'none', background:'var(--blue)', color:'#fff', fontWeight:600, fontSize:13, cursor:'pointer' }}>Connect & Push</button>
          <button style={{ flex:1, padding:'10px', borderRadius:8, border:'1px solid var(--border)', background:'var(--s3)', color:'var(--t2)', fontSize:13, cursor:'pointer' }}>Pull from Cloud</button>
        </div>
      </div>
    ),
    export: (
      <div>
        <H2>Export</H2>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {[['Export all trades as CSV','var(--blue)'],['Export all trades as JSON backup','var(--blue)'],['Export for Claude AI analysis','var(--purple)']].map(([l,c])=>(
            <button key={l} style={{ padding:'13px 16px', borderRadius:9, border:`1px solid ${c}30`, background:`${c}10`,
              color:c, fontSize:13, fontWeight:500, cursor:'pointer', textAlign:'left' }}>{l}</button>
          ))}
        </div>
        <Toggle2 val={true} onChange={()=>{}} label="Include trader name in exports"/>
        <Toggle2 val={false} onChange={()=>{}} label="Include account balance in exports"/>
      </div>
    ),
    danger: (
      <div>
        <H2>Danger Zone</H2>
        <p style={{ fontSize:13, color:'var(--t3)', marginBottom:20, lineHeight:1.6 }}>These actions are irreversible. Make sure you have a backup before proceeding.</p>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {[['Reset all settings to defaults','var(--amber)'],['Clear all trades','var(--red)'],['Wipe all data and start fresh','var(--red)']].map(([l,c])=>(
            <button key={l} style={{ padding:'13px 16px', borderRadius:9, border:`1px solid ${c}40`, background:`${c}08`,
              color:c, fontSize:13, fontWeight:600, cursor:'pointer', textAlign:'left' }}>{l}</button>
          ))}
        </div>
      </div>
    ),
  };

  return (
    <div style={{ display:'grid', gridTemplateColumns:'200px 1fr', gap:20, paddingBottom:40, minHeight:500 }}>
      {/* Settings sidebar */}
      <div style={{ background:'var(--s2)', border:'1px solid var(--border)', borderRadius:12, padding:8, alignSelf:'start', position:'sticky', top:0 }}>
        {SECTIONS.map(s => (
          <button key={s.id} onClick={() => setSection(s.id)} style={{
            display:'flex', alignItems:'center', gap:10, width:'100%', padding:'10px 12px',
            borderRadius:8, border:'none', cursor:'pointer', textAlign:'left', transition:'all 0.15s',
            background: section===s.id?'rgba(59,130,246,0.12)':'transparent',
            color: section===s.id?'var(--blue)':'var(--t3)', fontWeight: section===s.id?600:400, fontSize:13
          }}>
            <span style={{ fontSize:15 }}>{s.icon}</span>
            {s.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ background:'var(--s2)', border:'1px solid var(--border)', borderRadius:12, padding:28 }}>
        {content[section]}
        {section !== 'danger' && (
          <button onClick={save} style={{ marginTop:24, padding:'11px 28px', borderRadius:8, border:'none',
            background: saved?'var(--green)':'var(--blue)', color:'#fff', fontWeight:600, fontSize:14, cursor:'pointer', transition:'all 0.2s' }}>
            {saved ? '✓ Saved' : 'Save Settings'}
          </button>
        )}
      </div>
    </div>
  );
}

const H2 = ({ children }) => <div style={{ fontWeight:700, fontSize:17, color:'var(--t1)', marginBottom:20, paddingBottom:12, borderBottom:'1px solid var(--border)' }}>{children}</div>;
const H3 = ({ children }) => <div style={{ fontWeight:600, fontSize:13, color:'var(--t3)', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:14, marginTop:8 }}>{children}</div>;

Object.assign(window, { Settings });
