// LogTrade.jsx v2 — 4-step wizard with confluence grid
function LogTrade({ onSaved }) {
  const [step, setStep] = React.useState(1);
  const [saved, setSaved] = React.useState(false);
  const [form, setForm] = React.useState({
    pair:'GBP/USD', market:'Forex', direction:'Long',
    timeframe:'H1', setup:'Secondary POI + SC entry', session:'London',
    htfBias:'', monthlyBias:'', weeklyBias:'',
    poi:'', liquidity:'', mbms:'', sc:'', entryConf:'', momentum:'',
    bosTimeframe:'H1', dxy:'', dxyConfirms:'', trustedBOS:'',
    entry:'', sl:'', tp:'', risk:100, capital:10000,
    confidence:7, rationale:'',
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const calc = React.useMemo(() => {
    const e=parseFloat(form.entry), s=parseFloat(form.sl), t=parseFloat(form.tp);
    if (!e || !s) return {};
    const riskAmt = form.risk;
    const slDist = Math.abs(e-s);
    const tpDist = t ? Math.abs(e-t) : null;
    const slPips = slDist*10000;
    const lotSize = riskAmt/(slPips*10);
    const rr = tpDist ? (tpDist/slDist).toFixed(2) : null;
    return { slPips:slPips.toFixed(1), lotSize:lotSize.toFixed(2), rr };
  }, [form.entry, form.sl, form.tp, form.risk]);

  // Confluence score
  const confluenceScore = React.useMemo(() => {
    const checks = [form.htfBias, form.poi, form.liquidity, form.mbms, form.sc, form.entryConf];
    const positive = checks.filter(v => v && v !== 'No' && v !== 'None yet' && v !== 'Neutral').length;
    return { score: positive, total: 6 };
  }, [form.htfBias, form.poi, form.liquidity, form.mbms, form.sc, form.entryConf]);

  const STEPS = ['Instrument','Confluence','Levels','Review'];
  const progress = ((step-1)/(STEPS.length-1))*100;

  const inp = (extra={}) => ({
    background:'var(--s3)', border:'1px solid var(--border)', borderRadius:8,
    padding:'11px 13px', color:'var(--t1)', fontSize:14, width:'100%',
    outline:'none', boxSizing:'border-box', fontFamily:'inherit', ...extra
  });
  const lbl = { fontSize:11, color:'var(--t3)', marginBottom:6, display:'block', textTransform:'uppercase', letterSpacing:'0.06em' };
  const Row = ({ children }) => <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>{children}</div>;
  const Field = ({ label, children }) => <div><label style={lbl}>{label}</label>{children}</div>;

  // Confluence factor chip-group
  const CGroup = ({ label, field, opts, accent }) => {
    const active = form[field];
    const accentColor = accent || 'var(--blue)';
    return (
      <div style={{ background:'var(--s3)', borderRadius:10, padding:'12px 14px' }}>
        <div style={{ fontSize:11, color:'var(--t3)', marginBottom:8, textTransform:'uppercase', letterSpacing:'0.06em' }}>{label}</div>
        <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
          {opts.map(({ val, color }) => {
            const c = color || accentColor;
            const isActive = active === val;
            return (
              <button key={val} onClick={() => set(field, val)} style={{
                padding:'5px 12px', borderRadius:20, border:`1px solid ${isActive ? c : 'var(--border)'}`,
                background: isActive ? `${c}18` : 'transparent',
                color: isActive ? c : 'var(--t3)', fontSize:12, fontWeight: isActive?600:400,
                cursor:'pointer', transition:'all 0.15s'
              }}>{val}</button>
            );
          })}
        </div>
        {active && active !== 'No' && active !== 'None yet' && active !== 'Neutral' && (
          <div style={{ width:4, height:4, borderRadius:'50%', background:'var(--green)', marginTop:8 }}/>
        )}
      </div>
    );
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => { setSaved(false); if(onSaved) onSaved(form); }, 1500);
  };

  return (
    <div style={{ maxWidth:640, margin:'0 auto', paddingBottom:40 }}>
      {/* Step progress */}
      <div style={{ marginBottom:24 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
          {STEPS.map((s,i) => (
            <button key={s} onClick={()=>setStep(i+1)} style={{ background:'none', border:'none', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:5 }}>
              <div style={{ width:32, height:32, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center',
                background: step>i+1?'var(--green)':step===i+1?'var(--blue)':'var(--s3)',
                border:`2px solid ${step>i+1?'var(--green)':step===i+1?'var(--blue)':'var(--border)'}`,
                fontSize:12, fontWeight:700, color:step>=i+1?'#fff':'var(--t3)', transition:'all 0.2s' }}>
                {step>i+1?'✓':i+1}
              </div>
              <span style={{ fontSize:11, color:step===i+1?'var(--blue)':'var(--t3)', fontWeight:step===i+1?600:400 }}>{s}</span>
            </button>
          ))}
        </div>
        <div style={{ height:3, background:'var(--s3)', borderRadius:2 }}>
          <div style={{ height:'100%', width:`${progress}%`, background:'var(--blue)', borderRadius:2, transition:'width 0.4s ease' }}/>
        </div>
      </div>

      {/* Card */}
      <div style={{ background:'var(--s2)', border:'1px solid var(--border)', borderRadius:12, padding:26, marginBottom:14 }}>

        {/* STEP 1: Instrument */}
        {step===1 && (
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div style={{ fontWeight:700, fontSize:17, color:'var(--t1)' }}>Instrument & Setup</div>
            <Row>
              <Field label="Pair / Symbol"><input style={inp()} value={form.pair} onChange={e=>set('pair',e.target.value)}/></Field>
              <Field label="Market">
                <select style={inp({cursor:'pointer'})} value={form.market} onChange={e=>set('market',e.target.value)}>
                  {['Forex','BTC/USDT','Indices','Commodities','Other Crypto'].map(m=><option key={m}>{m}</option>)}
                </select>
              </Field>
            </Row>
            <Field label="Direction">
              <div style={{ display:'flex', gap:10 }}>
                {['Long','Short'].map(d=>(
                  <button key={d} onClick={()=>set('direction',d)} style={{
                    flex:1, padding:'12px', borderRadius:9, fontWeight:700, fontSize:15, cursor:'pointer',
                    border:`1px solid ${form.direction===d?(d==='Long'?'var(--green)':'var(--red)'):'var(--border)'}`,
                    background: form.direction===d?(d==='Long'?'rgba(34,197,94,0.12)':'rgba(239,68,68,0.12)'):'var(--s3)',
                    color: form.direction===d?(d==='Long'?'var(--green)':'var(--red)'):'var(--t3)', transition:'all 0.2s'
                  }}>{d==='Long'?'▲ Long':'▼ Short'}</button>
                ))}
              </div>
            </Field>
            <Row>
              <Field label="Entry Timeframe">
                <select style={inp({cursor:'pointer'})} value={form.timeframe} onChange={e=>set('timeframe',e.target.value)}>
                  {['M1','M5','M15','H1','H4','D1','W1'].map(t=><option key={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="Session">
                <select style={inp({cursor:'pointer'})} value={form.session} onChange={e=>set('session',e.target.value)}>
                  {['London','NY Session','Asian','London+NY Overlap'].map(s=><option key={s}>{s}</option>)}
                </select>
              </Field>
            </Row>
            <Field label="Setup Type">
              <select style={inp({cursor:'pointer'})} value={form.setup} onChange={e=>set('setup',e.target.value)}>
                {['Secondary POI + SC entry','Primary POI + SC entry','Trusted BOS entry','mbms confirmation entry','SC reaction only','HTF liquidity sweep entry','Other'].map(s=><option key={s}>{s}</option>)}
              </select>
            </Field>
          </div>
        )}

        {/* STEP 2: Confluence grid */}
        {step===2 && (
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div style={{ fontWeight:700, fontSize:17, color:'var(--t1)' }}>Confluence Analysis</div>
              {/* Score badge */}
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ fontFamily:'var(--mono)', fontWeight:700, fontSize:20,
                  color:confluenceScore.score>=5?'var(--green)':confluenceScore.score>=3?'var(--amber)':'var(--red)' }}>
                  {confluenceScore.score}/{confluenceScore.total}
                </div>
                <span style={{ fontSize:11, color:'var(--t3)' }}>confluence</span>
              </div>
            </div>

            {/* 6-factor grid */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10 }}>
              <CGroup label="HTF Bias (Daily)" field="htfBias" opts={[
                {val:'Bullish',color:'var(--green)'},{val:'Bearish',color:'var(--red)'},{val:'Neutral',color:'var(--t3)'}
              ]}/>
              <CGroup label="POI Level" field="poi" opts={[
                {val:'Secondary',color:'var(--blue)'},{val:'Primary',color:'var(--purple)'}
              ]}/>
              <CGroup label="$$ Liquidity Taken" field="liquidity" opts={[
                {val:'Yes',color:'var(--amber)'},{val:'Partial',color:'var(--amber)'},{val:'No',color:'var(--t3)'}
              ]} accent="var(--amber)"/>
              <CGroup label="mbms Confirmed" field="mbms" opts={[
                {val:'Yes',color:'var(--green)'},{val:'Forming',color:'var(--amber)'},{val:'No',color:'var(--red)'}
              ]}/>
              <CGroup label="SC Zone Visible" field="sc" opts={[
                {val:'Yes',color:'var(--grey-sc)'},{val:'Forming',color:'var(--amber)'},{val:'No',color:'var(--red)'}
              ]} accent="var(--grey-sc)"/>
              <CGroup label="Entry Confirmation" field="entryConf" opts={[
                {val:'HH+HL',color:'var(--green)'},{val:'LL+LH',color:'var(--red)'},{val:'Partial',color:'var(--amber)'},{val:'None yet',color:'var(--t3)'}
              ]}/>
            </div>

            {/* Score bar */}
            <div style={{ height:6, background:'var(--s3)', borderRadius:3, overflow:'hidden' }}>
              <div style={{ height:'100%', width:`${(confluenceScore.score/confluenceScore.total)*100}%`,
                background:confluenceScore.score>=5?'var(--green)':confluenceScore.score>=3?'var(--amber)':'var(--red)',
                borderRadius:3, transition:'width 0.3s' }}/>
            </div>

            {/* Extra context */}
            <Row>
              <Field label="BOS Timeframe">
                <select style={inp({cursor:'pointer'})} value={form.bosTimeframe} onChange={e=>set('bosTimeframe',e.target.value)}>
                  {['M1','M5','M15','H1','H4','D1','W1','Monthly'].map(t=><option key={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="Momentum">
                <div style={{ display:'flex', gap:8 }}>
                  {['Strong','Moderate','Weak'].map(v=>(
                    <button key={v} onClick={()=>set('momentum',v)} style={{
                      flex:1, padding:'10px 4px', borderRadius:8, border:`1px solid ${form.momentum===v?'var(--blue)':'var(--border)'}`,
                      background:form.momentum===v?'rgba(59,130,246,0.12)':'var(--s3)',
                      color:form.momentum===v?'var(--blue)':'var(--t3)', fontSize:12, fontWeight:form.momentum===v?600:400, cursor:'pointer'
                    }}>{v}</button>
                  ))}
                </div>
              </Field>
            </Row>
            <Row>
              <Field label="DXY at Key Level?">
                <select style={inp({cursor:'pointer'})} value={form.dxy} onChange={e=>set('dxy',e.target.value)}>
                  {['','Yes','No'].map(v=><option key={v} value={v}>{v||'— Select —'}</option>)}
                </select>
              </Field>
              <Field label="DXY Confirms Trade?">
                <select style={inp({cursor:'pointer'})} value={form.dxyConfirms} onChange={e=>set('dxyConfirms',e.target.value)}>
                  {['','Yes aligned','No conflicts','Neutral'].map(v=><option key={v} value={v}>{v||'— Select —'}</option>)}
                </select>
              </Field>
            </Row>
            <Field label={`Confidence: ${form.confidence}/10`}>
              <input type="range" min={1} max={10} value={form.confidence} onChange={e=>set('confidence',+e.target.value)}
                style={{ width:'100%', accentColor:'var(--blue)' }}/>
              <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'var(--t3)', marginTop:2 }}>
                <span>Low confidence</span><span>High confidence</span>
              </div>
            </Field>
          </div>
        )}

        {/* STEP 3: Trade Levels */}
        {step===3 && (
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div style={{ fontWeight:700, fontSize:17, color:'var(--t1)' }}>Trade Levels</div>
            {[['entry','Entry Price','var(--blue)'],['sl','Stop Loss','var(--red)'],['tp','Take Profit','var(--green)']].map(([k,l,c])=>(
              <Field key={k} label={l}>
                <input style={inp({ borderColor:`${c}40`, fontFamily:'var(--mono)', fontSize:16 })}
                  type="number" step="0.00001" value={form[k]} onChange={e=>set(k,e.target.value)} placeholder={k==='entry'?'e.g. 1.2695':k==='sl'?'e.g. 1.2660':'e.g. 1.2780'}/>
              </Field>
            ))}
            <Row>
              <Field label="Risk Amount ($)"><input style={inp({fontFamily:'var(--mono)'})} type="number" value={form.risk} onChange={e=>set('risk',+e.target.value)}/></Field>
              <Field label="Account Capital ($)"><input style={inp({fontFamily:'var(--mono)'})} type="number" value={form.capital} onChange={e=>set('capital',+e.target.value)}/></Field>
            </Row>
            {/* Live calc */}
            {calc.lotSize && (
              <div style={{ background:'var(--s3)', borderRadius:10, padding:16, display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, border:'1px solid var(--border)' }}>
                {[['Lot Size',calc.lotSize,'var(--blue)'],['SL (pips)',calc.slPips,'var(--red)'],['R:R',calc.rr?`1:${calc.rr}`:'—',parseFloat(calc.rr)>=2?'var(--green)':'var(--amber)']].map(([l,v,c])=>(
                  <div key={l} style={{ textAlign:'center' }}>
                    <div style={{ fontSize:10, color:'var(--t3)', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:5 }}>{l}</div>
                    <div style={{ fontFamily:'var(--mono)', fontWeight:700, fontSize:22, color:c }}>{v}</div>
                  </div>
                ))}
              </div>
            )}
            <Field label="Trade Rationale">
              <textarea style={{ ...inp(), height:90, resize:'vertical' }} value={form.rationale}
                onChange={e=>set('rationale',e.target.value)} placeholder="Why are you taking this trade? What does the structure say?"/>
            </Field>
          </div>
        )}

        {/* STEP 4: Review */}
        {step===4 && (
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div style={{ fontWeight:700, fontSize:17, color:'var(--t1)' }}>Review & Submit</div>
            {/* Confluence score summary */}
            <div style={{ background: confluenceScore.score>=5?'rgba(34,197,94,0.06)':'rgba(245,158,11,0.06)',
              border:`1px solid ${confluenceScore.score>=5?'rgba(34,197,94,0.2)':'rgba(245,158,11,0.2)'}`,
              borderRadius:10, padding:'14px 16px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <span style={{ fontSize:14, color:'var(--t2)' }}>Confluence Score</span>
              <span style={{ fontFamily:'var(--mono)', fontWeight:700, fontSize:20,
                color:confluenceScore.score>=5?'var(--green)':'var(--amber)' }}>
                {confluenceScore.score}/{confluenceScore.total}
              </span>
            </div>
            {[['Pair',`${form.pair} (${form.market})`],['Direction',form.direction],['Setup',form.setup],
              ['Session',form.session],['HTF Bias',form.htfBias||'—'],['POI',form.poi||'—'],
              ['$$ Taken',form.liquidity||'—'],['mbms',form.mbms||'—'],['SC Zone',form.sc||'—'],
              ['Entry Conf',form.entryConf||'—'],['Confidence',`${form.confidence}/10`],
              form.entry?['Entry',form.entry]:null, form.sl?['SL',form.sl]:null, form.tp?['TP',form.tp]:null,
              calc.rr?['R:R',`1:${calc.rr}`]:null, calc.lotSize?['Lot Size',`${calc.lotSize} lots`]:null,
            ].filter(Boolean).map(([k,v],i)=>(
              <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                padding:'8px 0', borderBottom:'1px solid var(--border)' }}>
                <span style={{ fontSize:13, color:'var(--t3)' }}>{k}</span>
                <span style={{ fontSize:13, fontFamily:/\d/.test(v)?'var(--mono)':'inherit', fontWeight:500,
                  color:v==='Bullish'||v==='Long'||v==='Yes'?'var(--green)':v==='Bearish'||v==='Short'||v==='No'?'var(--red)':'var(--t1)' }}>{v}</span>
              </div>
            ))}
            {form.rationale && (
              <div style={{ background:'var(--s3)', borderRadius:8, padding:12, fontSize:13, color:'var(--t2)', fontStyle:'italic', lineHeight:1.6 }}>
                "{form.rationale}"
              </div>
            )}
          </div>
        )}
      </div>

      {/* Nav */}
      <div style={{ display:'flex', gap:10 }}>
        <button onClick={()=>setStep(s=>Math.max(1,s-1))} disabled={step===1} style={{
          flex:1, padding:'13px', borderRadius:9, border:'1px solid var(--border)',
          background:'var(--s2)', color:step===1?'var(--t3)':'var(--t1)',
          fontWeight:600, fontSize:14, cursor:step===1?'not-allowed':'pointer' }}>← Back</button>
        {step<4 ? (
          <button onClick={()=>setStep(s=>s+1)} style={{
            flex:2, padding:'13px', borderRadius:9, border:'none', background:'var(--blue)',
            color:'#fff', fontWeight:600, fontSize:14, cursor:'pointer' }}>
            Continue → {STEPS[step]}
          </button>
        ) : (
          <button onClick={handleSave} style={{
            flex:2, padding:'13px', borderRadius:9, border:'none',
            background:saved?'var(--green)':'var(--green)', color:'#fff', fontWeight:600, fontSize:14, cursor:'pointer', transition:'all 0.2s' }}>
            {saved?'✓ Trade Saved!':'💾 Save Trade'}
          </button>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { LogTrade });
